import React from 'react';
import type { CrewStatus } from '../App';

const AgentStatusIcon: React.FC<{ status: CrewStatus['status'] }> = ({ status }) => {
    switch (status) {
        case 'working':
            return <div className="w-5 h-5 border-2 border-blue-400 border-t-transparent rounded-full animate-spin"></div>;
        case 'complete':
            return <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>;
        case 'error':
            return <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>;
        case 'pending':
        default:
            return <div className="w-5 h-5 border-2 border-gray-500 rounded-full"></div>;
    }
};

const AGENT_ORDER = [
    'Crew Manager',
    'Analyzer Agent',
    'Search Specialist',
    'Diagnostic Agent',
    'Resolution Proposer',
    'Communicator Agent'
];

const CrewActivityMonitor: React.FC<{ crewStatus: CrewStatus[] }> = ({ crewStatus }) => {
    
    const getStatusForAgent = (agentName: string): CrewStatus => {
        return crewStatus.find(s => s.agent === agentName) || { agent: agentName, status: 'pending' };
    };

    return (
        <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-6 shadow-2xl animate-fade-in">
            <h3 className="text-xl font-bold text-gray-100 mb-4">AI Crew Activity</h3>
            <div className="space-y-3">
                {AGENT_ORDER.map(agentName => {
                    const { status, message } = getStatusForAgent(agentName);
                    
                    let statusColor = 'text-gray-400';
                    if (status === 'working') statusColor = 'text-blue-400';
                    if (status === 'complete') statusColor = 'text-green-400';
                    if (status === 'error') statusColor = 'text-red-400';

                    return (
                        <div key={agentName} className="flex items-start p-3 bg-gray-900/50 rounded-lg">
                            <div className="flex-shrink-0 w-6 pt-1">
                                <AgentStatusIcon status={status} />
                            </div>
                            <div className="ml-4 flex-grow">
                                <p className="font-semibold text-gray-200">{agentName}</p>
                                <p className={`text-sm ${statusColor}`}>
                                    {message || status.charAt(0).toUpperCase() + status.slice(1)}
                                </p>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default CrewActivityMonitor;