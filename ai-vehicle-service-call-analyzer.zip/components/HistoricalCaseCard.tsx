
import React from 'react';
import type { HistoricalCase } from '../types';

interface HistoricalCaseCardProps {
  caseData: HistoricalCase;
}

const Tag: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <span className="inline-block bg-gray-600 text-gray-200 text-xs font-semibold mr-2 mb-2 px-2.5 py-1 rounded-full">
        {children}
    </span>
);


const HistoricalCaseCard: React.FC<HistoricalCaseCardProps> = ({ caseData }) => {
  return (
    <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-lg p-5 transition-shadow duration-300 hover:shadow-blue-500/20 hover:shadow-lg">
        <h4 className="text-lg font-bold text-blue-400">{caseData.vehicle.year} {caseData.vehicle.make} {caseData.vehicle.model}</h4>
        <p className="text-sm text-gray-400 mb-3">{caseData.vehicle.mileage.toLocaleString()} miles</p>

        <div className="mb-3">
            <p className="font-semibold text-gray-300">Symptoms:</p>
            <div className="flex flex-wrap mt-1">
                {caseData.symptoms.map(symptom => <Tag key={symptom}>{symptom}</Tag>)}
            </div>
        </div>
        
        <div className="mb-4">
            <p className="font-semibold text-gray-300">Fault Codes:</p>
            <div className="flex flex-wrap mt-1">
                {caseData.faultCodes.map(code => <Tag key={code}>{code}</Tag>)}
            </div>
        </div>

        <div>
            <p className="font-semibold text-gray-300">Resolution:</p>
            <p className="text-gray-400 bg-gray-900/50 p-3 rounded-md mt-1">{caseData.resolution}</p>
        </div>
    </div>
  );
};

export default HistoricalCaseCard;
