
import React from 'react';

interface AgentCardProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}

const AgentCard: React.FC<AgentCardProps> = ({ title, icon, children }) => {
  return (
    <div className="bg-gray-800 border border-gray-700 rounded-xl shadow-lg overflow-hidden transform hover:scale-[1.02] transition-transform duration-300">
      <div className="p-6">
        <div className="flex items-center mb-4">
          <div className="bg-gray-700 p-3 rounded-full mr-4 text-blue-400">
            {icon}
          </div>
          <h3 className="text-xl font-bold text-gray-100">{title}</h3>
        </div>
        <div className="text-gray-300 space-y-4">
          {children}
        </div>
      </div>
    </div>
  );
};

export default AgentCard;
